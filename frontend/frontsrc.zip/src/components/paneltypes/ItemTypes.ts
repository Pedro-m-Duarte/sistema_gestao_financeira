// src/components/paneltypes/ItemTypes.tsx
export const ItemTypes = {
    DiskSquare: 'diskSquare',
    CustomChart: 'customchart'
};