/// <reference types="react-scripts" />

/**
 * Para fazer as configurações dessas variáveis, vá até o arquivo 'env.ts'.
 */
declare const IS_DASH_AVAILABLE: boolean;
declare const PANEL_BACKEND_URL: string;
declare const ZABBIX_API_URL: string;