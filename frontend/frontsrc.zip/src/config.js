// src/config.js
const config = {
  appName: "Painel Titan",
};

export default config;